포트폴리오 - 유존정

코딩 스타일 참고용 샘플 프로젝트

	UnYui (UE5 C++)
		설명
			UE5 연습 목적으로 작업해본 간단한 작업물입니다.
			
			멀티 플레이 환경에서 많은 숫자의 투사체를 표현하는 것을 목표로 작업하였습니다.
			서버 : RPC 함수를 통해 투사체의 생성과 파괴만 클라이언트로 전달합니다.
			클라이언트 : UInstancedStaticMeshComponent 를 사용하여 메시를 출력하였습니다.
			
		첨부 파일
			1. \UnYui\UnYui.zip
				UE5 C++ 프로젝트
			2. \UnYui\플레이 영상.mp4
		입력
			이동 : WASD
			공격 : 마우스 왼쪽 클릭


	HC (C#)
		설명
			C# 연습 목적으로 작업해본 간단한 턴제 게임 시스템입니다.
			
			오브젝트 풀을 활용해서 성능 최적화를 시도하였습니다.
				class Unit 를 참고해주세요.
			게임 내의 데미지 이벤트가 발생할 때 관여하는 오브젝트들의 정보를 유지하여 자세한 정보 표시가 가능하도록 하였습니다.
				class DescValueBase 를 참고해주세요.
			
		첨부 파일
			1. \HC\HC.zip
				C# 프로젝트
		입력
			각 턴마다 해당 턴에 사용할 행동 방침 (가위/바위/보) 을 입력 받아서 진행하는 방식입니다.
			
			스테이지 리셋 및 시작 : reset
			다음 턴 행동 입력 : r|p|s
				ex) r
				각각 가위/바위/보 에 해당하는 입력입니다.
			스테이지 시뮬레이션 : sim #
				ex) sim 100
				입력된 횟수 만큼 스테이지를 시뮬레이션합니다.



메이플스토리 월드 프로젝트

	메이플 건보트
		설명
			메이플스토리 월드 컨텐츠 제작 업무로 작업한 협동 게임입니다.
		링크
			https://maplestoryworlds.nexon.com/ko/play/85440ddbd1e34f36853fe1e56a9ad6cb/

	노래 맞추기
		설명
			개인적으로 작업해본 노래 맞추기 맵입니다.
		링크
			노래 맞추기 맵
				https://maplestoryworlds.nexon.com/ko/play/c3bcf3fa83f3447bbe77aa101df3dfdd/
			템플릿으로 공개한 맵
				https://maplestoryworlds.nexon.com/ko/play/785bb491c4ab4c20b13645fb92a3a7c6/



개인 프로젝트

	maru
		설명
			13년 전에 개인적으로 작업했던 ARPG 프로토타입입니다.
			Windows GDI 를 사용한 C++ 프로젝트입니다.
