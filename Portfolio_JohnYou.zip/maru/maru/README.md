Credits for Sprites

	http://opengameart.org/content/one-more-lpc-alternate-character
	http://opengameart.org/content/alternate-lpc-character-sprites-george
	http://opengameart.org/content/420-pixel-art-icons-for-medievalfantasy-rpg
